<div id="nav" class="fix">
	<ul class="fix dropdown">
		<li class="page_item navfirst">
		
			<a class="home" href="<?php echo get_settings('home'); ?>/" title="<?php _e('Home',TDOMAIN);?>" style="background-image: url('<?php e_pagelines('nav_home_image', THEME_IMAGES.'/home-icon-trans.png');?>');">
				<?php _e('Home',TDOMAIN);?>	
			</a>
		</li>
		<?php 
			$frontpage_id = get_option('page_on_front');
			if($bbpress_forum && pagelinesforum('exclude_pages')){ $forum_exclude = ','.pagelinesforum('exclude_pages');}
			else{ $forum_exclude = '';}
			wp_list_pages('exclude='.$frontpage_id.$forum_exclude.'&depth=3&title_li=');?>
	</ul>
	<?php if(!pagelines('hidesearch')):?>
		<?php include (THEME_LIB . '/_searchform.php'); ?>
	<?php endif;?>
</div><!-- /nav -->