<div id="maincontent">
<div id="content">

	 <?php require(THEME_LIB.'/_posts.php');?>

</div> <!-- end content -->
</div>
<?php get_sidebar()?>