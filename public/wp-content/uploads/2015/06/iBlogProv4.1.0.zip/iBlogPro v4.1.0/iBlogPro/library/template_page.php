<?php if(pagelines('featureboxes', $post->ID) && VPRO) require(PRO.'/template_fboxes.php');?>
<!-- Standard Page Code -->
<div id="maincontent">
	<div id="content">

		 <?php require(THEME_LIB.'/_posts.php');?>

	</div> <!-- end content -->
</div>
<?php get_sidebar(); ?>
<!-- End Standard Page -->