<?php
if(VPRO) {
/*
	Template Name: Feature Page - Full Width Content
*/
	get_header(); 
		require(PRO.'/template_feature.php');
		require(THEME_LIB.'/template_fullwidth.php');
	get_footer(); 

}
?>