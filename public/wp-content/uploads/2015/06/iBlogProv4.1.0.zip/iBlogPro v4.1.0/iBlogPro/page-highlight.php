<?php
if(VPRO) {
/*
	Template Name: Highlight Page - Standard
*/

	get_header(); 

	require(PRO.'/template_highlight.php');
	require(THEME_LIB.'/template_page.php');

	get_footer(); 

}
?>
