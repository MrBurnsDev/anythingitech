<?php


	register_sidebar(array(
	'name'=>'main_sidebar',
	'description' => __('An option for the main sidebar. Graphical style: solid white/grey widgets with rounded corners.', TDOMAIN), 
	    'before_widget' => '<div id="%1$s" class="%2$s widget"><div class="winner">',
	    'after_widget' => '&nbsp;</div></div>',
	    'before_title' => '<h3 class="wtitle">',
	    'after_title' => '&nbsp;</h3>'
	));



if(VPRO) { include(PRO.'/sidebars_pro.php'); }

?>