
</div>
<?php include (THEME_LIB . '/_morefoot.php'); ?>
<div  id="footer">
	<div class="effect">
		<div class="content">
			<?php if(pagelines('twitfooter') && pagelines('twittername') && VPRO):?>
				<div id="footer_topline"><?php include (THEME_LIB . '/_twittermessages.php'); ?></div>
			<?php endif;?>
			<div id="fcolumns_container" class="fix">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Columns') ) : ?>
					<div class="fcol">
						<div class="fcol_pad">
							<?php if(pagelines('footer_logo') && VPRO):?>
								<a class="home" href="<?php echo get_settings('home'); ?>/" title="<?php _e('Home',TDOMAIN);?>">
									<img src="<?php echo pagelines('footer_logo');?>" alt="<?php bloginfo('name');?>" />
								</a>
							<?php else:?>
								<h3 class="footer-site-title"><a class="home" href="<?php echo get_settings('home'); ?>/" title="<?php _e('Home',TDOMAIN);?>"><?php bloginfo('name');?></a></h3>
							<?php endif;?>
						</div>
					</div>
					<div class="fcol">
						<div class="fcol_pad">
							<h3><?php _e('Pages',TDOMAIN);?></h3>
							<?php include(THEME_LIB."/_footer_nav.php");?>
						</div>
					</div>
					<div class="fcol">
						<div class="fcol_pad">
							<h3><?php _e('Stay In Touch',TDOMAIN);?></h3>
								<ul>

									<li><a href="<?php echo RSSURL;?>" class="rsslink"><?php _e('Site RSS Feed', TDOMAIN);?></a></li>
								<?php if(VPRO):?>
									<?php if(pagelines('twitterlink')):?>
										<li><a href="<?php echo pagelines('twitterlink');?>" class="twitterlink">Twitter</a></li>
									<?php endif;?>
									<?php if(pagelines('facebooklink')):?>
										<li><a href="<?php echo pagelines('facebooklink');?>" class="facebooklink">Facebook</a></li>
									<?php endif;?>
									<?php if(pagelines('linkedinlink')):?>
										<li><a href="<?php echo pagelines('linkedinlink');?>" class="linkedinlink">LinkedIn</a></li>
									<?php endif;?>
								<?php endif;?>
								</ul>

						</div>
					</div>
					<div class="fcol">
						<div class="fcol_pad">
							<h3><?php _e('More',TDOMAIN);?></h3>
							<?php if(pagelines('welcomemessage')):?><div class="welcomemessage"><?php echo pagelines('welcomemessage');?></div><?php endif;?>
						</div>
					</div>
					<div class="fcol">
						<div class="fcol_pad">
							<span class="terms">
								<?php e_pagelines('terms');?>
							</span>
						</div>
					</div>
				<?php endif; ?>
			</div>
	
		
			<div class="clear"></div>
		</div>		
	</div>


</div>
	<div class="clear"></div>
<?php if(pagelines('no_credit') || !VDEV):?>
	<div id="cred" class="pagelines">
		<a class="plimage" target="_blank" href="<?php e_pagelines('partner_link', pagelines('credlink'));?>">
			<?php e_pagelines('credtext', 'PageLines Themes');?>
		</a>
	</div>
<?php elseif(!VPRO):?>
	<div id="cred" class="pagelines">
		<a class="plimage" target="_blank" href="<?php e_pagelines('partner_link', pagelines('credlink'));?>">
			PageLines Themes
		</a>
	</div>
<?php endif;?>
 	<hr class="hidden" />

  </div><!--/wrapper -->

</div><!--/page -->

<!-- Footer Scripts Go Here -->
<?php if (pagelines('footerscripts')) echo pagelines('footerscripts');?>
<!-- End Footer scripts -->

<?php wp_footer(); ?>
</body>
</html>