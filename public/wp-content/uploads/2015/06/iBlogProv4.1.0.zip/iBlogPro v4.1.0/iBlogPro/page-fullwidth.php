<?php
/*
Template Name: Full Width Page
*/
?>
<?php get_header(); ?>

<?php require(THEME_LIB.'/template_fullwidth.php');?>

<?php get_footer(); ?>
