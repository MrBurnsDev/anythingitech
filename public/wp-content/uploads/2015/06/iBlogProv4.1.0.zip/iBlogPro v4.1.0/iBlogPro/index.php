<?php 
/*
	iBlogPro3 Copyright (C) 2008-2010 Andrew Powers, PageLines.com (andrew AT pagelines DOT com)

	Licensed under the terms of GPL
*/

global $pagelines;


	get_header(); 
	if(pagelines('featureblog') && VPRO) include(PRO.'/template_feature.php');
	include(THEME_LIB.'/template_posts.php');
	get_footer();
	
	
?>