<?php get_header(); ?>

<?php require(THEME_LIB.'/template_page.php');?>

<?php get_footer(); ?>
