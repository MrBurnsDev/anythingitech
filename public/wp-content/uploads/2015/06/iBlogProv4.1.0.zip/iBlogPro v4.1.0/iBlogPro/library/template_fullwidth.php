<?php if(pagelines('featureboxes', $post->ID) && VPRO) require(PRO.'/template_fboxes.php');?>
<div id="content">

	 <?php require(THEME_LIB.'/_posts.php');?>

</div> <!-- end content -->